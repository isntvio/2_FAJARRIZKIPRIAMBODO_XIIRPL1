<?php
session_start();
date_default_timezone_set('Asia/Jakarta');

// Koneksi Database
$conn = mysqli_connect("localhost", "root", "", "parkirfajar");
if (!$conn) { die("Koneksi gagal: " . mysqli_connect_error()); }

// --- 1. LOGIKA LOGIN & LOGOUT ---
if (isset($_POST['login'])) {
    $u = mysqli_real_escape_string($conn, $_POST['username']); 
    $p = mysqli_real_escape_string($conn, $_POST['password']);
    $q = mysqli_query($conn, "SELECT * FROM tb_user WHERE username='$u' AND password='$p' AND status_aktif=1");
    if (mysqli_num_rows($q) > 0) {
        $d = mysqli_fetch_assoc($q);
        $_SESSION['role'] = $d['role'];
        $_SESSION['nama'] = $d['nama_lengkap'];
        $_SESSION['id_user'] = $d['id_user'];
        header("Location: index.php"); exit();
    }
}
if (isset($_GET['logout'])) { session_destroy(); header("Location: index.php"); exit(); }

$role = $_SESSION['role'] ?? null;
$page = $_GET['page'] ?? 'dashboard';
$uid  = $_SESSION['id_user'] ?? 0;

// --- 2. PROTEKSI AKSES ROLE ---
if ($role == 'admin' && in_array($page, ['transaksi', 'struk', 'rekap'])) { header("Location: index.php"); exit(); }
if ($role == 'petugas' && in_array($page, ['user', 'tarif', 'area', 'rekap', 'kendaraan', 'log'])) { header("Location: index.php"); exit(); }
if ($role == 'owner' && !in_array($page, ['dashboard', 'rekap'])) { header("Location: index.php"); exit(); }

// --- 3. PROSES CRUD & TRANSAKSI ---
if (isset($_POST['aksi'])) {
    $aksi = $_POST['aksi'];
    
    // CRUD USER
    if ($aksi == 'tambah_user') {
        $nama = trim(mysqli_real_escape_string($conn, $_POST['nama'] ?? ''));
        $user = trim(mysqli_real_escape_string($conn, $_POST['user'] ?? ''));
        $pass = trim(mysqli_real_escape_string($conn, $_POST['pass'] ?? ''));
        $role_u = trim(mysqli_real_escape_string($conn, $_POST['role_u'] ?? ''));
        if (!empty($nama) && !empty($user) && !empty($pass)) {
            mysqli_query($conn, "INSERT INTO tb_user (nama_lengkap, username, password, role, status_aktif) VALUES ('$nama', '$user', '$pass', '$role_u', 1)");
        }
    } elseif ($aksi == 'hapus_user') {
        mysqli_query($conn, "UPDATE tb_user SET status_aktif = 0 WHERE id_user = '$_POST[id]'");
    }

    // CRUD TARIF
    elseif ($aksi == 'tambah_tarif') {
        $jenis = trim(mysqli_real_escape_string($conn, $_POST['jenis'] ?? ''));
        $tarif = trim(mysqli_real_escape_string($conn, $_POST['tarif'] ?? ''));
        if (!empty($jenis) && !empty($tarif)) {
            mysqli_query($conn, "INSERT INTO tb_tarif (jenis_kendaraan, tarif_per_jam) VALUES ('$jenis', '$tarif')");
        }
    } elseif ($aksi == 'hapus_tarif') {
        mysqli_query($conn, "DELETE FROM tb_tarif WHERE id_tarif = '$_POST[id]'");
    }

    // CRUD AREA
    elseif ($aksi == 'tambah_area') {
        $nama_a = trim(mysqli_real_escape_string($conn, $_POST['nama_a'] ?? ''));
        $kapasitas = trim(mysqli_real_escape_string($conn, $_POST['kapasitas'] ?? ''));
        if (!empty($nama_a) && !empty($kapasitas)) {
            mysqli_query($conn, "INSERT INTO tb_area_parkir (nama_area, kapasitas, terisi) VALUES ('$nama_a', '$kapasitas', 0)");
        }
    } elseif ($aksi == 'hapus_area') {
        mysqli_query($conn, "DELETE FROM tb_area_parkir WHERE id_area = '$_POST[id]'");
    }

    // LOGIKA MASUK PARKIR
    elseif ($aksi == 'masuk_parkir') {
        $plat = strtoupper(trim(mysqli_real_escape_string($conn, $_POST['plat'] ?? '')));
        $id_t = trim(mysqli_real_escape_string($conn, $_POST['id_t'] ?? ''));
        $id_a = trim(mysqli_real_escape_string($conn, $_POST['id_a'] ?? ''));
        
        $res_t = mysqli_query($conn, "SELECT jenis_kendaraan FROM tb_tarif WHERE id_tarif = '$id_t'");
        $row_t = mysqli_fetch_assoc($res_t);
        $jenis_k = $row_t['jenis_kendaraan'];

        $cek_k = mysqli_query($conn, "SELECT id_kendaraan FROM tb_kendaraan WHERE plat_nomor = '$plat'");
        if (mysqli_num_rows($cek_k) > 0) {
            $dk = mysqli_fetch_assoc($cek_k);
            $id_k = $dk['id_kendaraan'];
        } else {
            mysqli_query($conn, "INSERT INTO tb_kendaraan (plat_nomor, jenis_kendaraan, id_user) VALUES ('$plat', '$jenis_k', '$uid')");
            $id_k = mysqli_insert_id($conn);
        }

        mysqli_query($conn, "INSERT INTO tb_transaksi (id_kendaraan, waktu_masuk, id_tarif, status, id_user, id_area) VALUES ('$id_k', NOW(), '$id_t', 'masuk', '$uid', '$id_a')");
        mysqli_query($conn, "UPDATE tb_area_parkir SET terisi = terisi + 1 WHERE id_area = '$id_a'");

    } elseif ($aksi == 'keluar_parkir') {
        $id_p = $_POST['id_p'];
        $dt = mysqli_fetch_assoc(mysqli_query($conn, "SELECT t.*, tr.tarif_per_jam FROM tb_transaksi t JOIN tb_tarif tr ON t.id_tarif = tr.id_tarif WHERE t.id_parkir = '$id_p'"));
        $masuk = new DateTime($dt['waktu_masuk']); $keluar = new DateTime(); $diff = $masuk->diff($keluar);
        $durasi = $diff->h + ($diff->days * 24); if($diff->i > 0) $durasi++; if($durasi == 0) $durasi = 1;
        $total = $durasi * $dt['tarif_per_jam'];
        mysqli_query($conn, "UPDATE tb_transaksi SET waktu_keluar=NOW(), durasi_jam='$durasi', biaya_total='$total', status='keluar' WHERE id_parkir='$id_p'");
        mysqli_query($conn, "UPDATE tb_area_parkir SET terisi = terisi - 1 WHERE id_area = '$dt[id_area]'");
    }
    header("Location: index.php?page=$page"); exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Aplikasi Parkir UKK</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <style>
        :root { --primary: #0d6efd; --bg: #f0f2f5; }
        body { background: var(--bg); font-family: 'Segoe UI', sans-serif; color: #333; }
        .header-blue { background: var(--primary); color: white; padding: 25px 0; border-radius: 0 0 30px 30px; text-align: center; margin-bottom: 25px; }
        .main-card { background: #ffffff; border-radius: 25px; padding: 25px; min-height: 500px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .nav-pills .nav-link.active { background: var(--primary) !important; color: white !important; font-weight: bold; }
        .table { color: #212529 !important; }
        @media print { .no-print { display: none !important; } .card { border: none !important; } }
    </style>
</head>
<body>

<?php if (!$role): ?>
    <div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="card p-4 shadow border-0" style="width: 350px;">
            <h4 class="text-center fw-bold mb-4 text-primary">APLIKASI PARKIR</h4>
            <form method="POST">
                <div class="mb-3"><input type="text" name="username" class="form-control" placeholder="Username" required></div>
                <div class="mb-4"><input type="password" name="password" class="form-control" placeholder="Password" required></div>
                <button type="submit" name="login" class="btn btn-primary w-100 fw-bold">MASUK</button>
            </form>
        </div>
    </div>
<?php else: ?>
    <div class="header-blue no-print">
        <h4 class="fw-bold m-0 text-uppercase">Sistem Manajemen Parkir</h4>
        <p class="m-0 small">Login: <strong><?= strtoupper($role) ?></strong> (<?= $_SESSION['nama'] ?>)</p>
    </div>

    <div class="container pb-5">
        <div class="main-card">
            <ul class="nav nav-pills justify-content-center mb-4 no-print">
                <li class="nav-item"><a class="nav-link <?= $page=='dashboard'?'active':'' ?>" href="?page=dashboard">Dashboard</a></li>
                <?php if($role == 'admin'): ?>
                    <li class="nav-item"><a class="nav-link <?= $page=='user'?'active':'' ?>" href="?page=user">User</a></li>
                    <li class="nav-item"><a class="nav-link <?= $page=='tarif'?'active':'' ?>" href="?page=tarif">Tarif</a></li>
                    <li class="nav-item"><a class="nav-link <?= $page=='area'?'active':'' ?>" href="?page=area">Area</a></li>
                    <li class="nav-item"><a class="nav-link <?= $page=='kendaraan'?'active':'' ?>" href="?page=kendaraan">Kendaraan</a></li>
                    <li class="nav-item"><a class="nav-link <?= $page=='log'?'active':'' ?>" href="?page=log">Log</a></li>
                <?php elseif($role == 'petugas'): ?>
                    <li class="nav-item"><a class="nav-link <?= ($page=='transaksi' || $page=='struk')?'active':'' ?>" href="?page=transaksi">Transaksi</a></li>
                <?php elseif($role == 'owner'): ?>
                    <li class="nav-item"><a class="nav-link <?= $page=='rekap'?'active':'' ?>" href="?page=rekap">Rekap Laporan</a></li>
                <?php endif; ?>
                <li class="nav-item"><a class="nav-link text-danger fw-bold" href="?logout=1">Keluar</a></li>
            </ul>

            <div class="content">
                <?php if($page == 'dashboard'): ?>
                    <div class="row g-3 text-center">
                        <div class="col-md-6"><div class="card p-4 border-0 shadow-sm bg-light"><h6>Kendaraan Parkir</h6><h3 class="fw-bold text-primary"><?= mysqli_num_rows(mysqli_query($conn, "SELECT * FROM tb_transaksi WHERE status='masuk'")) ?></h3></div></div>
                        <div class="col-md-6"><div class="card p-4 border-0 shadow-sm bg-light"><h6>Pemasukan Hari Ini</h6><h3 class="fw-bold text-success">Rp <?= number_format(mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(biaya_total) as total FROM tb_transaksi WHERE DATE(waktu_keluar)=CURDATE()"))['total'] ?? 0) ?></h3></div></div>
                    </div>

                <?php elseif($page == 'user' && $role == 'admin'): ?>
                    <div class="card p-3 mb-3 border-0 shadow-sm bg-light">
                        <h6 class="fw-bold">Tambah Pengguna</h6>
                        <form method="POST" class="row g-2">
                            <input type="hidden" name="aksi" value="tambah_user">
                            <div class="col-md-3"><input type="text" name="nama" class="form-control" placeholder="Nama Lengkap" required></div>
                            <div class="col-md-3"><input type="text" name="user" class="form-control" placeholder="Username" required></div>
                            <div class="col-md-2"><input type="password" name="pass" class="form-control" placeholder="Password" required></div>
                            <div class="col-md-2"><select name="role_u" class="form-select"><option value="admin">Admin</option><option value="petugas">Petugas</option><option value="owner">Owner</option></select></div>
                            <div class="col-md-2"><button type="submit" class="btn btn-primary w-100">Simpan</button></div>
                        </form>
                    </div>
                    <table class="table border">
                        <thead class="table-dark"><tr><th>Nama</th><th>Username</th><th>Role</th><th>Aksi</th></tr></thead>
                        <tbody><?php $qu=mysqli_query($conn,"SELECT * FROM tb_user WHERE status_aktif=1"); while($ru=mysqli_fetch_assoc($qu)): ?>
                            <tr><td><?=$ru['nama_lengkap']?></td><td><?=$ru['username']?></td><td><span class="badge bg-secondary"><?=$ru['role']?></span></td>
                            <td><form method="POST"><input type="hidden" name="aksi" value="hapus_user"><input type="hidden" name="id" value="<?=$ru['id_user']?>"><button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button></form></td></tr>
                        <?php endwhile; ?></tbody>
                    </table>

                <?php elseif($page == 'tarif' && $role == 'admin'): ?>
                    <div class="card p-3 mb-3 border-0 shadow-sm bg-light">
                        <h6 class="fw-bold">Kelola Tarif</h6>
                        <form method="POST" class="row g-2">
                            <input type="hidden" name="aksi" value="tambah_tarif">
                            <div class="col-md-5"><input type="text" name="jenis" class="form-control" placeholder="Jenis (Motor/Mobil)" required></div>
                            <div class="col-md-5"><input type="number" name="tarif" class="form-control" placeholder="Tarif Per Jam" required></div>
                            <div class="col-md-2"><button type="submit" class="btn btn-primary w-100">Tambah</button></div>
                        </form>
                    </div>
                    <table class="table border">
                        <thead class="table-dark"><tr><th>Jenis Kendaraan</th><th>Tarif / Jam</th><th>Aksi</th></tr></thead>
                        <tbody><?php $qt=mysqli_query($conn,"SELECT * FROM tb_tarif"); while($rt=mysqli_fetch_assoc($qt)): ?>
                            <tr><td><strong><?=$rt['jenis_kendaraan']?></strong></td><td>Rp <?=number_format($rt['tarif_per_jam'])?></td>
                            <td><form method="POST"><input type="hidden" name="aksi" value="hapus_tarif"><input type="hidden" name="id" value="<?=$rt['id_tarif']?>"><button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button></form></td></tr>
                        <?php endwhile; ?></tbody>
                    </table>

                <?php elseif($page == 'area' && $role == 'admin'): ?>
                    <div class="card p-3 mb-3 border-0 shadow-sm bg-light">
                        <h6 class="fw-bold">Area Parkir</h6>
                        <form method="POST" class="row g-2">
                            <input type="hidden" name="aksi" value="tambah_area">
                            <div class="col-md-5"><input type="text" name="nama_a" class="form-control" placeholder="Nama Area" required></div>
                            <div class="col-md-5"><input type="number" name="kapasitas" class="form-control" placeholder="Kapasitas Slot" required></div>
                            <div class="col-md-2"><button type="submit" class="btn btn-primary w-100">Tambah</button></div>
                        </form>
                    </div>
                    <table class="table border">
                        <thead class="table-dark"><tr><th>Area</th><th>Slot</th><th>Terisi</th><th>Aksi</th></tr></thead>
                        <tbody><?php $qa=mysqli_query($conn,"SELECT * FROM tb_area_parkir"); while($ra=mysqli_fetch_assoc($qa)): ?>
                            <tr><td><?=$ra['nama_area']?></td><td><?=$ra['kapasitas']?></td><td><?=$ra['terisi']?></td>
                            <td><form method="POST"><input type="hidden" name="aksi" value="hapus_area"><input type="hidden" name="id" value="<?=$ra['id_area']?>"><button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button></form></td></tr>
                        <?php endwhile; ?></tbody>
                    </table>

                <?php elseif($page == 'kendaraan' && $role == 'admin'): ?>
                    <h6 class="fw-bold mb-3">Master Data Kendaraan (Unik)</h6>
                    <table class="table border">
                        <thead class="table-dark"><tr><th>ID</th><th>Plat Nomor</th><th>Jenis</th><th>Terdaftar Oleh</th></tr></thead>
                        <tbody><?php $qk = mysqli_query($conn, "SELECT k.*, u.nama_lengkap FROM tb_kendaraan k JOIN tb_user u ON k.id_user = u.id_user ORDER BY k.id_kendaraan DESC"); while($rk = mysqli_fetch_assoc($qk)): ?>
                            <tr><td><?=$rk['id_kendaraan']?></td><td><span class="badge bg-primary"><?=$rk['plat_nomor']?></span></td><td><?=$rk['jenis_kendaraan']?></td><td><?=$rk['nama_lengkap']?></td></tr>
                        <?php endwhile; ?></tbody>
                    </table>

                <?php elseif($page == 'log' && $role == 'admin'): ?>
                    <h6 class="fw-bold mb-3">Log Aktivitas Petugas</h6>
                    <table class="table border">
                        <thead class="table-dark"><tr><th>Waktu Masuk</th><th>Plat</th><th>Status</th><th>Area</th><th>Petugas</th></tr></thead>
                        <tbody><?php $ql = mysqli_query($conn, "SELECT t.*, k.plat_nomor, u.nama_lengkap, a.nama_area FROM tb_transaksi t JOIN tb_kendaraan k ON t.id_kendaraan = k.id_kendaraan JOIN tb_user u ON t.id_user = u.id_user LEFT JOIN tb_area_parkir a ON t.id_area = a.id_area ORDER BY t.id_parkir DESC"); while($rl = mysqli_fetch_assoc($ql)): ?>
                            <tr><td><small><?=$rl['waktu_masuk']?></small></td><td><strong><?=$rl['plat_nomor']?></strong></td><td><?=$rl['status'] == 'masuk' ? '<span class="badge bg-success">Masuk</span>' : '<span class="badge bg-danger">Keluar</span>'?></td><td><span class="badge bg-dark"><?=$rl['nama_area'] ?? '-'?></span></td><td><?=$rl['nama_lengkap']?></td></tr>
                        <?php endwhile; ?></tbody>
                    </table>

                <?php elseif($page == 'transaksi' && $role == 'petugas'): ?>
                    <div class="card p-3 mb-3 border-0 shadow-sm bg-light">
                        <form method="POST" class="row g-2">
                            <input type="hidden" name="aksi" value="masuk_parkir">
                            <div class="col-md-3"><input type="text" name="plat" class="form-control" placeholder="PLAT NOMOR" required onkeyup="this.value = this.value.toUpperCase()"></div>
                            <div class="col-md-3"><select name="id_t" class="form-select"><?php $t=mysqli_query($conn,"SELECT * FROM tb_tarif"); while($rt=mysqli_fetch_assoc($t)) echo "<option value='$rt[id_tarif]'>$rt[jenis_kendaraan]</option>"; ?></select></div>
                            <div class="col-md-3"><select name="id_a" class="form-select"><?php $a=mysqli_query($conn,"SELECT * FROM tb_area_parkir"); while($ra=mysqli_fetch_assoc($a)) echo "<option value='$ra[id_area]'>$ra[nama_area] (Sisa: ".($ra['kapasitas']-$ra['terisi']).")</option>"; ?></select></div>
                            <div class="col-md-3"><button type="submit" class="btn btn-primary w-100 fw-bold">MASUK</button></div>
                        </form>
                    </div>
                    <table class="table border">
                        <thead class="table-primary"><tr><th>Plat</th><th>Jenis</th><th>Area</th><th>Masuk</th><th>Aksi</th></tr></thead>
                        <tbody><?php 
                        $qh=mysqli_query($conn,"SELECT t.*, k.plat_nomor, k.jenis_kendaraan, a.nama_area 
                                                FROM tb_transaksi t 
                                                JOIN tb_kendaraan k ON t.id_kendaraan=k.id_kendaraan 
                                                LEFT JOIN tb_area_parkir a ON t.id_area=a.id_area
                                                ORDER BY t.id_parkir DESC"); 
                        while($rh=mysqli_fetch_assoc($qh)): ?>
                            <tr>
                                <td><strong><?=$rh['plat_nomor']?></strong></td>
                                <td><?=$rh['jenis_kendaraan']?></td>
                                <td><span class="badge bg-dark"><?=$rh['nama_area'] ?? '-' ?></span></td>
                                <td><?=date('H:i',strtotime($rh['waktu_masuk']))?></td>
                                <td>
                                    <?php if($rh['status']=='masuk'): ?>
                                        <form method="POST">
                                            <input type="hidden" name="aksi" value="keluar_parkir">
                                            <input type="hidden" name="id_p" value="<?=$rh['id_parkir']?>">
                                            <button class="btn btn-sm btn-danger">Keluar</button>
                                        </form>
                                    <?php else: ?>
                                        <a href="?page=struk&id=<?=$rh['id_parkir']?>" class="btn btn-sm btn-info text-white"><i class="bi bi-printer"></i> Struk</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?></tbody>
                    </table>

                <?php elseif($page == 'rekap' && $role == 'owner'): ?>
                    <div class="card p-3 mb-3 no-print bg-light">
                        <form method="GET" class="row g-2">
                            <input type="hidden" name="page" value="rekap">
                            <div class="col-md-4"><input type="date" name="t1" class="form-control" value="<?= $_GET['t1'] ?? '' ?>"></div>
                            <div class="col-md-4"><input type="date" name="t2" class="form-control" value="<?= $_GET['t2'] ?? '' ?>"></div>
                            <div class="col-md-4"><button type="submit" class="btn btn-primary w-100">Filter Laporan</button></div>
                        </form>
                    </div>
                    <?php if(isset($_GET['t1'])): ?>
                        <div class="bg-white p-4 border">
                            <h5 class="text-center fw-bold">REKAP TRANSAKSI PARKIR</h5>
                            <p class="text-center small">Periode: <?= $_GET['t1'] ?> s/d <?= $_GET['t2'] ?></p>
                            <table class="table table-bordered mt-3">
                                <thead class="table-light"><tr><th>Waktu Keluar</th><th>Plat Nomor</th><th>Area</th><th>Total Biaya</th></tr></thead>
                                <tbody><?php 
                                $total=0; 
                                $t1 = $_GET['t1']; $t2 = $_GET['t2'];
                                $qr=mysqli_query($conn,"SELECT t.*, k.plat_nomor, a.nama_area FROM tb_transaksi t JOIN tb_kendaraan k ON t.id_kendaraan=k.id_kendaraan LEFT JOIN tb_area_parkir a ON t.id_area=a.id_area WHERE DATE(t.waktu_keluar) BETWEEN '$t1' AND '$t2' AND t.status='keluar'"); while($rr=mysqli_fetch_assoc($qr)): $total+=$rr['biaya_total']; ?>
                                    <tr><td><small><?=$rr['waktu_keluar']?></small></td><td><strong><?=$rr['plat_nomor']?></strong></td><td><span class="badge bg-dark"><?=$rr['nama_area'] ?? '-'?></span></td><td class="text-end"><?=number_format($rr['biaya_total'])?></td></tr>
                                <?php endwhile; ?></tbody>
                                <tfoot><tr><th colspan="3" class="text-center">TOTAL PENDAPATAN</th><th class="text-end">Rp <?=number_format($total)?></th></tr></tfoot>
                            </table>
                            <button onclick="window.print()" class="btn btn-secondary no-print w-100">Cetak Laporan</button>
                        </div>
                    <?php endif; ?>

                <?php elseif($page == 'struk'): ?>
                    <?php 
                    $id=$_GET['id']; 
                    $ds=mysqli_fetch_assoc(mysqli_query($conn,"SELECT t.*, k.plat_nomor FROM tb_transaksi t JOIN tb_kendaraan k ON t.id_kendaraan=k.id_kendaraan WHERE t.id_parkir='$id'")); 
                    ?>
                    <div class="card p-4 mx-auto text-center shadow-sm" style="max-width: 300px; background: white; border: 1px dashed #000;">
                        <h6 class="fw-bold">STRUK PARKIR</h6><hr>
                        <h3><?=$ds['plat_nomor']?></h3>
                        <div class="text-start small mt-3">Masuk: <?=$ds['waktu_masuk']?><br>Keluar: <?=$ds['waktu_keluar']?><br>Durasi: <?=$ds['durasi_jam']?> Jam</div><hr>
                        <h4 class="fw-bold">Rp <?=number_format($ds['biaya_total'])?></h4>
                        <button onclick="window.print()" class="btn btn-dark btn-sm no-print w-100 mt-2">Print</button>
                        <a href="?page=transaksi" class="btn btn-light btn-sm no-print w-100 mt-1 border">Kembali</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endif; ?>
</body>
</html>